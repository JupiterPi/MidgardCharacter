package jupiterpa.model.dto;

import lombok.Data;

@Data
public class RewardDTO {
    String characterId;
    int ep;
    int gold;
}
