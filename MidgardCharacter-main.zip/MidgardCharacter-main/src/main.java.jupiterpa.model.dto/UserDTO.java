package jupiterpa.model.dto;

import lombok.Data;

@Data
public class UserDTO {
    String id;
    String name;
    String password;
}
