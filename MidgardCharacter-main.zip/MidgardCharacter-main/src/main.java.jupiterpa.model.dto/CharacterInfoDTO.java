package jupiterpa.model.dto;

import lombok.Data;

@Data
public class CharacterInfoDTO {
    String id;
    String name;
    String userId;
}
